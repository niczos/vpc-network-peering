# Copyright 2021 by Google.
# Your use of any copyrighted material and any warranties, if applicable, are subject to your agreement with Google.

import googleapiclient.discovery
from google.oauth2 import service_account
from google.cloud import monitoring_v3
from google.api import metric_pb2 as ga_metric
import time
import os
from flask import escape

def peer(event, context):

    # SET YOUR OWN VARIABLES TO PROJECT WHERE THE METRIC WILL BE CREATED
    SERVICE_ACCOUNT_FILE = '<Path to your key file (in json) for service account>'
    PEERING_NAME         = '<Name of peering connection>'
    DIRECTION            = '<The direction of the exchanged routes - INCOMING or OUTGOING>'
    NETWORK              = '<Name of the network for this request>'
    PROJECT_ID           = '<Project ID for this request>'
    REGION               = '<The region of the request>'

    # SET YOUR OWN VARIABLES TO ANOTHER PROJECT FROM WHICH NUMBER OF PEERED NETWORKS WILL BE RECEIVED
    # (create as many projects as you need)
    SERVICE_ACCOUNT_FILE_1 = '<Path to your key file (in json) for service account>'
    PEERING_NAME_1         = '<Name of peering connection>'
    DIRECTION_1            = '<The direction of the exchanged routes - INCOMING or OUTGOING>'
    NETWORK_1              = '<Name of the network for this request>'
    PROJECT_ID_1           = '<Project ID for this request>'
    REGION_1               = '<The region of the request>'

    METRIC_NAME          = "number-of-peered-networks-metric"  # change if needed

    # Sets environment variable
    try:
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = SERVICE_ACCOUNT_FILE
    except NameError:
        print('Variable does not exist')

    SCOPES = ['https://www.googleapis.com/auth/cloud-platform']


    ########## CREATE CUSTOM METRIC ##########

    client = monitoring_v3.MetricServiceClient()
    project_name = f"projects/{PROJECT_ID}"
    descriptor = ga_metric.MetricDescriptor()
    descriptor.type = f"custom.googleapis.com/{METRIC_NAME}"
    descriptor.metric_kind = ga_metric.MetricDescriptor.MetricKind.GAUGE
    descriptor.value_type = ga_metric.MetricDescriptor.ValueType.DOUBLE
    descriptor.description = "VPC peering network metric."

    descriptor = client.create_metric_descriptor(name=project_name, metric_descriptor=descriptor)
    print("Created {}.".format(descriptor.name))

    def write_data(project_id, network, direction, peering_name, region, sa_file):

        ########## GET NUMBER OF PEERED NETWORKS #########

        credentials = service_account.Credentials.from_service_account_file(sa_file, scopes=SCOPES)
        compute = googleapiclient.discovery.build('compute', 'v1', credentials=credentials)
        response = compute.networks().listPeeringRoutes(project=f'{project_id}', network=f'{network}',
                direction=f'{direction}', peeringName=f'{peering_name}', region=f'{region}').execute()

        if 'items' in response:
            length = len(response['items'])


        ########### WRITE DATA TO CUSTOM METRIC ##########

        series = monitoring_v3.TimeSeries()
        series.metric.type = f"custom.googleapis.com/{METRIC_NAME}"
        series.resource.type = "global"
        series.metric.labels["project_id"] = project_id

        now = time.time()
        seconds = int(now)
        nanos = int((now - seconds) * 10 ** 9)
        interval = monitoring_v3.TimeInterval({"end_time": {"seconds": seconds, "nanos": nanos}})
        point = monitoring_v3.Point({"interval": interval, "value": {"double_value": length}})
        series.points = [point]
        client.create_time_series(name=project_name, time_series=[series])

        print(f"Wrote number of vpc peered networks from project {project_id} to metric.")

    write_data(PROJECT_ID,NETWORK, DIRECTION, PEERING_NAME, REGION, SERVICE_ACCOUNT_FILE)
    time.sleep(0.1)
    write_data(PROJECT_ID_1,NETWORK_1, DIRECTION_1, PEERING_NAME_1, REGION_1, SERVICE_ACCOUNT_FILE_1)
    # multiple running of the function "write_data" as many times as number of projects

    return ('Success')
